<?php
    require __DIR__ .'/../vendor/autoload.php';

    class Test extends PHPUnit_Framework_TestCase
    {
        public function testExample()
        {
            $result = Example\Example::go();
        }
    }
?>  
