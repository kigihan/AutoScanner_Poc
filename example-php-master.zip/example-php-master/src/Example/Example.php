<?php namespace Example;

class Example
{
    public static function go()
    {
        if (false) {
            return true;
        }

        return false;
        
    }
}
